<?php
include('db.php');
session_start();

if (isset($_POST['submit'])) {
    $namaalbum = $_POST['namaalbum'];
    $userid = $_POST['userid'];

    $insert = mysqli_query($conn, "INSERT INTO `tb_category`(`category_id`, `category_name`, `userid`) VALUES (NULL,'$namaalbum','$userid')");
    header('location:album.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WEB Galeri Foto</title>
    <link rel="stylesheet" type="text/css" href="css/foto.css">

</head>

<body class="box">
    <header>
        <div class="container">

            <h1><a href="index.php">WEB GALERI FOTO</a></h1>
            <ul>
                <li><a href="dashboard.php">dashboard</a></li>
                <!-- <li><a href="galeri.php">Galeri</a></li> -->
                <li><a href="profil.php">Profil</a></li>
                <!-- <li><a href="registrasi.php">Registrasi</a></li> -->
                <li><a href="data-image.php">Data Foto</a></li>
                <li><a href="tambah-image.php">Tambah</a></li>
                <?php if ($_SESSION['login'] = '') { ?>
                    <li><a href="login.php">Login</a></li>
                <?php } ?>
            </ul>
        </div>
    </header>
    <div class="naon" style="width: 100%; height: 100vh ; display:flex; justify-content: center; align-items: center;">
    <div style="flex-direction: column; display:flex; justify-content: center; align-items: center;"  > 
        <h2>album</h2> 
        <form action="" method="POST" style="flex-direction: column; display:flex; justify-content: center; align-items: start;">
            <input type="text" name="namaalbum" placeholder="Nama Album" style="width: 60%% height: 32px ; padding: 5px;">
            <input type="hidden" name="userid" placeholder="userid" class="input-control"
                value='<?= $_SESSION["a_global"]->admin_id ?>'>
            <input type="submit" name="submit" value="tambah" class="btn">
        </form>
        </div>
    </div>
</body>

</html>