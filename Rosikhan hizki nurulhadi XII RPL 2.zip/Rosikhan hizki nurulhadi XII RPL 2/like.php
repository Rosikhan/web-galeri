<?php 
include('db.php');

// Tangani permintaan like

if (isset($_POST['FotoID'])) {
    $user_id = $_POST['UserID']; // Anda perlu mendapatkan ID pengguna yang sesuai disini
    $FotoID = $_POST['FotoID'];

    // Periksa apakah pengguna sudah like sebelumnya atau tidak
    $query = "SELECT * FROM likefoto WHERE UserID = $user_id AND FotoID = $FotoID";
    $result = mysqli_query($conn, $query);


    if (mysqli_num_rows($result) == 0) {

        // Jika pengguna belum like sebelumnya, simpan like ke database
        // $insert_query = "INSERT INTO likefoto VALUES (Null, $user_id, $FotoID, current_timestamp()";
        $insert_query = "INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES (NULL, '$FotoID', '$user_id', current_timestamp());";
        $insert_result = mysqli_query($conn, $insert_query);

        if ($insert_result) {
            echo "<script>window.location='detail-image.php?id=$FotoID'</script>";
        } else {
            echo "Gagal menyimpan like: " . mysqli_error($conn);
        }
    } else {
        $delete_like = "DELETE FROM likefoto WHERE `likefoto`.`FotoID` = $FotoID AND `likefoto`.`UserID` = $user_id";
        $result = mysqli_query($conn, $delete_like);
        echo "<br>";
        echo $user_id;
        echo "<script>window.location='detail-image.php?id=$FotoID'</script>";
    }
}

?>