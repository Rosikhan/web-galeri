<?php
    error_reporting();
    include 'db.php';
    session_start();

    $FotoID = $_GET['id'];
	$kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
	$a = mysqli_fetch_object($kontak);
	
    $queryLike = "SELECT COUNT(*) FROM likefoto WHERE FotoID = $FotoID";
    $hasilLike = mysqli_query($conn, $queryLike);
    $u = mysqli_fetch_assoc($hasilLike);

	$produk = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_id = '".$_GET['id']."' ");
	$p = mysqli_fetch_object($produk);

    if(isset($_POST['hapus-comment'])){
        $komentarid=$_POST['idcomment'];
        // echo $_POST['idcomment'];

        $sql=mysqli_query($conn,"DELETE FROM comments WHERE comments.id= '$komentarid' ");

    }

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>WEB Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/foto.css">
</head>

<body class="box">
    <!-- header -->
    <header>
        <div class="container">
        <h1><a href="index.php">WEB GALERI FOTO</a></h1>
        <ul>
            <li><a href="galeri.php">Galeri</a></li>
           <!-- <li><a href="registrasi.php">Registrasi</a></li> -->
           <li><a href="login.php">Login</a></li>
        </ul>
        </div>
    </header>
  
    <!-- search -->
    <div class="search">
        <div class="container">
            <form action="galeri.php">
                <!-- <input type="text" name="search" placeholder="Cari Foto" value="<?php echo $_GET['search'] ?>" /> -->
                <!-- <input type="hidden" name="kat" value="<?php echo $_GET['kat'] ?>" /> -->
                <!-- <input type="submit" name="cari" value="Cari Foto" /> -->
            </form>
        </div>
    </div>
    
    <!-- product detail -->
    <div class="section">
        <div class="container">
             <h3>Detail Foto</h3>
            <div class="">
                <div class="col-2">
                   <img src="foto/<?php echo $p->image ?>" width="100%" /> 
                </div>
                <div class="col-2">
                   <h3><?php echo $p->image_name ?><br />Kategori : <?php echo $p->category_name  ?></h3>
                   <h4>Nama User : <?php echo $p->admin_name ?><br />
                   Upload Pada Tanggal : <?php echo $p->date_created  ?></h4>
                   <p>Deskripsi :<br />
                        <?php echo $p->image_description ?>
                   </p>

                    <!-- Misalnya, ini adalah konten artikel -->
                    <form action="like.php" method="post">
                        <input type="hidden" name="UserID" value="<?= $_SESSION["a_global"]->admin_id ?>">
                        <input type="hidden" name="FotoID" value="<?= $FotoID ?>">
                        <!-- <input type="submit" name="like" id=""> -->
                        <button type="submit" name="like">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16">
                                <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
                                </svg>
                            </span>
                            <h4 style="color: black; float:right; margin-left:4px"><?= $u["COUNT(*)"] ?></h4>
                        </button>
                        <!-- <h4 style="color: black;"><?= $u["COUNT(*)"] ?></h4> -->
                    </form>

                     <!-- Misalnya, ini adalah komentar -->
                   <form method="post" action="comments.php">
                   <!-- <label for="name">Nama:</label><br>
                   <input type="text" id="name" name="name" required><br> -->
                   <label for="comment">Komentar:</label><br>
                   <input type="hidden" name="FotoID-com" value="<?= $FotoID ?>">
                   <input type="hidden" name="UserID-com" value="<?= $_SESSION["a_global"]->admin_id ?>">
                   <textarea id="comment" name="comment" rows="4" cols="50" required></textarea><br>
                   <input type="submit" name="komen" value="Submit">
                   
                   
               </form>

               <?php $select = mysqli_query($conn, "SELECT comments.*, tb_admin.username FROM comments INNER JOIN tb_admin ON tb_admin.admin_id = comments.user_id WHERE comments.photo_id = $FotoID");
               while($row = mysqli_fetch_assoc($select)){ ?> 
               <p style="padding: 0; margin:0;"><?= $row['username'] ?> <br>  <?= $row['comment_text'] ?></p>
               <form action="" method="post">
                <input type="hidden" name="idcomment" value="<?= $row['id'] ?>">
                <input type="submit" name="hapus-comment" id="" value="hapus">
               </form>
               <?php }?>
            
  

                   <!-- <form action="" method="post">
                    <input type="submit" name="like" id="" value="like">
                   </form> -->
                   
                </div>
            </div>
        </div>
    </div>
    
    <!-- footer -->
    <!-- <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri Foto.</small>
        </div>
    </footer> -->
</body>
</html>