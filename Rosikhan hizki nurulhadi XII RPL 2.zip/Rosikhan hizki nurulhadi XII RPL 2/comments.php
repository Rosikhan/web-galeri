<?php
include 'db.php';
session_start();


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['komen'])) {
    // $name = $_POST['name'];
    $comment = $_POST['comment'];
    $FotoIDcom = $_POST['FotoID-com'];
    $UserID = $_POST['UserID-com'];

    if($_SESSION["a_global"]->admin_id == 0) {
        header('location:index.php');
    } else {
        $sql = "INSERT INTO `comments`(`id`, `photo_id`, `user_id`, `comment_text`, `created_at`) VALUES ('','$FotoIDcom','$UserID','$comment','')";
        $query = mysqli_query($conn, $sql);

        echo "<script>window.location='detail-image.php?id=$FotoIDcom'</script>";
    }

    
}
?>