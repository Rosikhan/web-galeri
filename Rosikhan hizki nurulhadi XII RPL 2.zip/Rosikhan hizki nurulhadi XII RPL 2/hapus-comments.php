<?php
    include "db.php";
    session_start();

    $komentarid=$_GET['komentarid'];
    $FotoID = $_GET['fotoid'];

    $sql=mysqli_query($conn,"delete from comments where id= '$komentarid' ");

    // header("<script>window.location='detail-image.php'</script>");
    header('location:index.php');
?>